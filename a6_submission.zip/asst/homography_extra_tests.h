#include "homography.h"
#include "matrix.h"
#include <cassert>
#include <iostream>

using namespace std;

void testStitchScience() {
  // // --------- HANDOUT  PS06 ------------------------------
  // 6.8370 write a test
}

void testStitchConvention() {
  // // --------- HANDOUT  PS06 ------------------------------
  // 6.8370 write a test
}

void testStitchBoston1() {
  // // --------- HANDOUT  PS06 ------------------------------
  // 6.8370 write a test
}
